package com.jarvis.ai

import android.app.*
import android.content.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

class Msg(val role: String, val text: String)
class Q(val q: String, val o: List<String>, val a: Int)

object Store {
    fun get(c: Context, k: String, d: String = "") = c.getSharedPreferences("jarvis", 0).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) = c.getSharedPreferences("jarvis", 0).edit().putString(k, v).apply()
    fun list(c: Context, k: String): List<String> = JSONArray(get(c, k, "[]")).let { a -> (0 until a.length()).map { a.getString(it) } }
    fun saveList(c: Context, k: String, l: List<String>) = put(c, k, JSONArray(l).toString())
    fun history(c: Context) = list(c, "hist").map { JSONObject(it).let { o -> Msg(o.getString("r"), o.getString("t")) } }
    fun saveHistory(c: Context, m: List<Msg>) {
        if (get(c, "save", "1") == "1") saveList(c, "hist", m.takeLast(200).map { JSONObject().put("r", it.role).put("t", it.text).toString() })
    }
    fun today() = "focus_" + LocalDate.now()
    fun focusOn(c: Context, d: LocalDate) = get(c, "focus_$d", "0").toInt()
    fun addFocus(c: Context, min: Int) = put(c, today(), (focusOn(c, LocalDate.now()) + min).toString())
}

object Prompt {
    fun langLine(c: Context) = when (Store.get(c, "lang", "Auto")) {
        "English" -> "\nAlways reply in English."
        "Tamil" -> "\nAlways reply in Tamil script (தமிழ்)."
        "Tanglish" -> "\nAlways reply in Tanglish: Tamil written in English letters mixed naturally with English."
        else -> "\nMirror the user's language: English, Tamil, or Tanglish (Tamil in English letters)."
    }
    fun system(c: Context) = """You are JARVIS, a smart, warm, patient AI study assistant inspired by Iron Man's assistant. 
Speak naturally and friendly, like a great tutor. Explain subjects simply, step by step, with a real-life example, and end with a quick check question when useful. 
Keep answers concise (replies may be read aloud), avoid heavy markdown. Be honest when unsure. Encourage focus and good study habits.""" + langLine(c)
    const val QUIZ = "You create quizzes. Reply with ONLY a JSON array of 5 multiple-choice questions, no other text: [{\"q\":\"question\",\"o\":[\"A\",\"B\",\"C\",\"D\"],\"a\":0}] where a is the 0-based index of the correct option."
}

object Api {
    suspend fun chat(c: Context, msgs: List<Pair<String, String>>, system: String): String = withContext(Dispatchers.IO) {
        val url = Store.get(c, "url").trim()
        if (url.isBlank()) return@withContext "Open Settings and enter your backend URL and App Token first."
        val arr = JSONArray()
        msgs.takeLast(20).dropWhile { it.first != "user" }.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
        try {
            val h = URL(url).openConnection() as HttpURLConnection
            h.requestMethod = "POST"; h.doOutput = true; h.connectTimeout = 20000; h.readTimeout = 90000
            h.setRequestProperty("Content-Type", "application/json")
            h.setRequestProperty("X-App-Token", Store.get(c, "token"))
            h.outputStream.use { it.write(JSONObject().put("system", system).put("messages", arr).toString().toByteArray()) }
            val txt = (if (h.responseCode < 400) h.inputStream else h.errorStream).bufferedReader().readText()
            JSONObject(txt).optString("text", "Error: " + txt.take(200))
        } catch (e: Exception) { "Connection error: ${e.message}" }
    }
}

fun remind(c: Context, text: String, min: Int) {
    val i = Intent(c, Alarm::class.java).putExtra("t", text)
    val pi = PendingIntent.getBroadcast(c, (System.currentTimeMillis() % 100000).toInt(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    c.getSystemService(AlarmManager::class.java).set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + min * 60000L, pi)
}

class Alarm : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("r", "Reminders", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(System.nanoTime().toInt(), Notification.Builder(c, "r").setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("JARVIS reminder").setContentText(i.getStringExtra("t")).build())
    }
}
