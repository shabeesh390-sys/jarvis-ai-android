package com.jarvis.ai

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

val Cyan = Color(0xFF00E5FF); val Bg = Color(0xFF020608); val Panel = Color(0xFF0A161B)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) { App() }
        }
    }
}

object Focus {
    var left by mutableIntStateOf(25 * 60); var total by mutableIntStateOf(25 * 60)
    var running by mutableStateOf(false); var focus by mutableStateOf(true)
    fun mode(f: Boolean) { focus = f; total = if (f) 25 * 60 else 5 * 60; left = total; running = false }
    fun tick(c: Context) {
        left--
        if (left <= 0) { if (focus) Store.addFocus(c, total / 60); mode(!focus) }
    }
}

@Composable fun App() {
    val c = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val msgs = remember { mutableStateListOf<Msg>().also { it.addAll(Store.history(c)) } }
    LaunchedEffect(Focus.running) { while (Focus.running) { delay(1000); Focus.tick(c) } }
    val tabs = listOf("💬" to "Chat", "📚" to "Study", "⏱" to "Focus", "📱" to "Usage", "⚙" to "Settings")
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Panel) {
            tabs.forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(t.first) },
                    label = { Text(t.second, fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(selectedTextColor = Cyan, unselectedTextColor = Color.Gray, indicatorColor = Cyan.copy(.2f)))
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Bg)) {
            when (tab) { 0 -> ChatScreen(msgs); 1 -> StudyScreen(); 2 -> FocusScreen(); 3 -> UsageScreen(); else -> SettingsScreen(msgs) }
        }
    }
}

// ---------- shared UI ----------
@Composable fun Core(size: Dp, active: Boolean) {
    val t = rememberInfiniteTransition(label = "core")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (active) 2500 else 9000, easing = LinearEasing)), label = "r")
    val pulse by t.animateFloat(0.85f, 1.08f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    Canvas(Modifier.size(size)) {
        val c = center; val r = this.size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(.55f), Color.Transparent), c, r * pulse), r * pulse, c)
        drawCircle(Cyan, r * .26f * pulse, c)
        rotate(rot) {
            val s = Size(r * 1.6f, r * 1.6f); val o = Offset(c.x - r * .8f, c.y - r * .8f)
            drawArc(Cyan, 0f, 80f, false, o, s, style = Stroke(r * .06f, cap = StrokeCap.Round))
            drawArc(Cyan, 180f, 80f, false, o, s, style = Stroke(r * .06f, cap = StrokeCap.Round))
        }
        rotate(-rot * 1.6f) {
            val s = Size(r * 1.1f, r * 1.1f); val o = Offset(c.x - r * .55f, c.y - r * .55f)
            drawArc(Cyan.copy(.7f), 40f, 280f, false, o, s, style = Stroke(r * .03f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 14f))))
        }
    }
}
@Composable fun Glow(mod: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(mod.border(1.dp, Cyan.copy(.35f), RoundedCornerShape(16.dp)).background(Panel, RoundedCornerShape(16.dp)).padding(12.dp), content = content)
@Composable fun CBtn(t: String, mod: Modifier = Modifier, onClick: () -> Unit) =
    OutlinedButton(onClick, mod, border = BorderStroke(1.dp, Cyan), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) { Text(t) }
@Composable fun Field(v: String, on: (String) -> Unit, hint: String, mod: Modifier = Modifier, num: Boolean = false) =
    OutlinedTextField(v, on, mod, placeholder = { Text(hint, color = Color.Gray) }, shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (num) KeyboardType.Number else KeyboardType.Text),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(.4f), cursorColor = Cyan))
@Composable fun Title(t: String) = Text(t, color = Cyan, fontSize = 20.sp, letterSpacing = 3.sp)

// ---------- Chat ----------
@Composable fun ChatScreen(msgs: SnapshotStateList<Msg>) {
    val c = LocalContext.current; val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }; var listening by remember { mutableStateOf(false) }
    val tts = remember { TextToSpeech(c) {} }; val rec = remember { SpeechRecognizer.createSpeechRecognizer(c) }
    DisposableEffect(Unit) { onDispose { tts.shutdown(); rec.destroy() } }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size, busy) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size) }
    fun send(t: String) {
        if (t.isBlank() || busy) return
        msgs.add(Msg("user", t.trim())); input = ""; busy = true
        scope.launch {
            val r = Api.chat(c, msgs.map { it.role to it.text }, Prompt.system(c))
            msgs.add(Msg("assistant", r)); busy = false; Store.saveHistory(c, msgs)
            if (Store.get(c, "voice", "1") == "1") {
                tts.language = Locale(if (Store.get(c, "lang") == "Tamil") "ta" else "en", "IN")
                tts.speak(r, TextToSpeech.QUEUE_FLUSH, null, "j")
            }
        }
    }
    fun listen() {
        tts.stop()
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (Store.get(c, "lang") == "Tamil") "ta-IN" else "en-IN")
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(r: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) { listening = false }
            override fun onResults(b: Bundle?) { listening = false; b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { send(it) } }
        })
        listening = true; rec.startListening(i)
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) listen() }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Core(44.dp, busy || listening); Spacer(Modifier.width(10.dp)); Title("J.A.R.V.I.S")
        }
        if (msgs.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Core(190.dp, false); Spacer(Modifier.height(16.dp))
                Text("Hello! I'm JARVIS. What shall we learn today?", textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                listOf("Explain photosynthesis simply", "Newton laws ah Tanglish la explain pannu", "Make a 3-day study plan for maths").forEach {
                    CBtn(it, Modifier.padding(2.dp)) { send(it) }
                }
            }
        } else LazyColumn(Modifier.weight(1f), list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(msgs) { _, m ->
                val me = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start) {
                    Text(m.text, Modifier.widthIn(max = 300.dp)
                        .border(1.dp, Cyan.copy(if (me) .9f else .3f), RoundedCornerShape(16.dp))
                        .background(if (me) Cyan.copy(.15f) else Panel, RoundedCornerShape(16.dp)).padding(12.dp))
                }
            }
            item { if (busy) Text("JARVIS is thinking…", color = Cyan) else Spacer(Modifier.height(1.dp)) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Field(input, { input = it }, if (listening) "Listening…" else "Ask JARVIS anything", Modifier.weight(1f))
            IconButton({ if (c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) listen() else perm.launch(Manifest.permission.RECORD_AUDIO) }) { Text("🎤", fontSize = 24.sp) }
            IconButton({ send(input) }) { Text("➤", color = Cyan, fontSize = 24.sp) }
        }
    }
}

// ---------- Study ----------
@Composable fun StudyScreen() {
    var t by remember { mutableIntStateOf(0) }
    Column {
        TabRow(t, containerColor = Bg, contentColor = Cyan) { listOf("Planner", "Quiz", "Notes").forEachIndexed { i, s -> Tab(t == i, { t = i }, text = { Text(s) }) } }
        when (t) { 0 -> PlannerTab(); 1 -> QuizTab(); else -> NotesTab() }
    }
}

@Composable fun PlannerTab() {
    val c = LocalContext.current
    val tasks = remember { mutableStateListOf<String>().also { it.addAll(Store.list(c, "tasks")) } }
    var txt by remember { mutableStateOf("") }; var min by remember { mutableStateOf("") }
    fun save() = Store.saveList(c, "tasks", tasks)
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Field(txt, { txt = it }, "Task (e.g. Revise Chapter 3)", Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) {
            Field(min, { min = it }, "Remind in (min)", Modifier.weight(1f), true); Spacer(Modifier.width(8.dp))
            CBtn("Add") {
                if (txt.isNotBlank()) {
                    tasks.add(0, "0:" + txt.trim()); save()
                    min.toIntOrNull()?.takeIf { it > 0 }?.let { remind(c, txt.trim(), it) }
                    txt = ""; min = ""
                }
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(tasks) { i, s ->
                val done = s.startsWith("1:")
                Glow(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(done, { tasks[i] = (if (it) "1:" else "0:") + s.drop(2); save() }, colors = CheckboxDefaults.colors(checkedColor = Cyan))
                        Text(s.drop(2), Modifier.weight(1f), textDecoration = if (done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null)
                        TextButton({ tasks.removeAt(i); save() }) { Text("✕", color = Color.Gray) }
                    }
                }
            }
        }
    }
}

@Composable fun QuizTab() {
    val c = LocalContext.current; val scope = rememberCoroutineScope()
    var topic by remember { mutableStateOf("") }; var qs by remember { mutableStateOf<List<Q>>(emptyList()) }
    var i by remember { mutableIntStateOf(0) }; var score by remember { mutableIntStateOf(0) }; var pick by remember { mutableIntStateOf(-1) }
    var busy by remember { mutableStateOf(false) }; var err by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Field(topic, { topic = it }, "Quiz topic (e.g. Photosynthesis)", Modifier.fillMaxWidth())
        CBtn(if (busy) "Generating…" else "Generate 5-question quiz", Modifier.fillMaxWidth()) {
            if (topic.isNotBlank() && !busy) {
                busy = true; err = ""
                scope.launch {
                    val r = Api.chat(c, listOf("user" to "Topic: $topic"), Prompt.QUIZ + Prompt.langLine(c))
                    qs = parseQuiz(r); if (qs.isEmpty()) err = r.take(200); i = 0; score = 0; pick = -1; busy = false
                }
            }
        }
        if (err.isNotEmpty()) Text(err, color = Color(0xFFFF6B6B))
        if (qs.isNotEmpty()) Glow(Modifier.fillMaxWidth()) {
            if (i < qs.size) {
                val q = qs[i]
                Text("Question ${i + 1}/${qs.size}", color = Cyan); Spacer(Modifier.height(6.dp)); Text(q.q, fontSize = 18.sp); Spacer(Modifier.height(8.dp))
                q.o.forEachIndexed { idx, o ->
                    val col = when { pick < 0 -> Cyan; idx == q.a -> Color(0xFF4CFF8F); idx == pick -> Color(0xFFFF6B6B); else -> Color.Gray }
                    OutlinedButton({ if (pick < 0) { pick = idx; if (idx == q.a) score++ } }, Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        border = BorderStroke(1.dp, col)) { Text(o, color = col) }
                }
                if (pick >= 0) CBtn(if (i == qs.size - 1) "Finish" else "Next") { i++; pick = -1 }
            } else { Title("SCORE"); Text("$score / ${qs.size}", fontSize = 32.sp) }
        }
    }
}

fun parseQuiz(s: String): List<Q> = try {
    val a = JSONArray(s.substring(s.indexOf('['), s.lastIndexOf(']') + 1))
    (0 until a.length()).map { val o = a.getJSONObject(it); val op = o.getJSONArray("o")
        Q(o.getString("q"), (0 until op.length()).map { j -> op.getString(j) }, o.getInt("a")) }
} catch (e: Exception) { emptyList() }

@Composable fun NotesTab() {
    val c = LocalContext.current
    val notes = remember { mutableStateListOf<String>().also { it.addAll(Store.list(c, "notes")) } }
    var txt by remember { mutableStateOf("") }
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Field(txt, { txt = it }, "Write a note…", Modifier.fillMaxWidth())
        CBtn("Save note") { if (txt.isNotBlank()) { notes.add(0, txt.trim()); Store.saveList(c, "notes", notes); txt = "" } }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(notes) { i, n ->
                Glow(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.Top) {
                    Text(n, Modifier.weight(1f)); TextButton({ notes.removeAt(i); Store.saveList(c, "notes", notes) }) { Text("✕", color = Color.Gray) } } }
            }
        }
    }
}

// ---------- Focus ----------
@Composable fun FocusScreen() {
    val c = LocalContext.current
    val f = Focus
    val week = (0..6).map { Store.focusOn(c, LocalDate.now().minusDays(it.toLong())) }
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Title(if (f.focus) "FOCUS MODE" else "BREAK TIME")
        Box(Modifier.size(260.dp), contentAlignment = Alignment.Center) {
            val prog by animateFloatAsState(f.left / f.total.toFloat(), label = "p")
            Canvas(Modifier.fillMaxSize()) {
                val st = Stroke(14f, cap = StrokeCap.Round)
                drawArc(Cyan.copy(.15f), 0f, 360f, false, style = st)
                drawArc(Cyan, -90f, 360f * prog, false, style = st)
            }
            Text("%02d:%02d".format(f.left / 60, f.left % 60), fontSize = 52.sp, color = Cyan)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CBtn(if (f.running) "Pause" else "Start") { f.running = !f.running }
            CBtn("Reset") { f.mode(f.focus) }
            CBtn(if (f.focus) "Break (5)" else "Focus (25)") { f.mode(!f.focus) }
        }
        Glow(Modifier.fillMaxWidth()) {
            Text("Studied today: ${week[0]} min", fontSize = 18.sp)
            Text("Last 7 days: ${week.sum()} min", color = Color.Gray)
        }
    }
}

// ---------- Screen time ----------
fun hasUsage(c: Context): Boolean {
    @Suppress("DEPRECATION")
    return c.getSystemService(AppOpsManager::class.java).checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
}
fun fmt(ms: Long) = "${ms / 3600000}h ${ms / 60000 % 60}m"

@Composable fun UsageScreen() {
    val c = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val ok = remember(tick) { hasUsage(c) }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Title("SCREEN TIME")
        if (!ok) {
            Glow(Modifier.fillMaxWidth()) {
                Text("JARVIS needs Usage Access to show app usage. Data stays on your phone.")
                CBtn("Grant Usage Access") { c.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            }
            CBtn("I've enabled it – Refresh") { tick++ }
        } else {
            val z = ZoneId.systemDefault(); val usm = c.getSystemService(UsageStatsManager::class.java)
            val data = remember(tick) {
                val now = System.currentTimeMillis()
                val s = LocalDate.now().atStartOfDay(z).toInstant().toEpochMilli()
                val today = usm.queryAndAggregateUsageStats(s, now).values.filter { it.totalTimeInForeground > 60000 && it.packageName != c.packageName }
                    .sortedByDescending { it.totalTimeInForeground }.take(15).map { u ->
                        val pm = c.packageManager
                        (runCatching { pm.getApplicationLabel(pm.getApplicationInfo(u.packageName, 0)).toString() }.getOrDefault(u.packageName)) to u.totalTimeInForeground }
                val week = (6 downTo 0).map { d ->
                    val a = LocalDate.now().minusDays(d.toLong()).atStartOfDay(z).toInstant().toEpochMilli()
                    usm.queryAndAggregateUsageStats(a, minOf(a + 86400000, now)).values.sumOf { it.totalTimeInForeground }
                }
                today to week
            }
            val (apps, week) = data
            Glow(Modifier.fillMaxWidth()) {
                Text("Today: ${fmt(apps.sumOf { it.second })} (top apps)", fontSize = 20.sp, color = Cyan)
                Row(Modifier.fillMaxWidth().height(70.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                    val mx = (week.maxOrNull() ?: 1L).coerceAtLeast(1L)
                    week.forEach { Box(Modifier.width(24.dp).height((60 * it / mx + 4).dp).background(Cyan.copy(.8f), RoundedCornerShape(4.dp))) }
                }
                Text("Last 7 days →", color = Color.Gray, fontSize = 12.sp)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(apps) { _, (n, t) ->
                    Column { Row { Text(n, Modifier.weight(1f)); Text(fmt(t), color = Cyan) }
                        LinearProgressIndicator(progress = { t / apps.first().second.toFloat() }, Modifier.fillMaxWidth(), color = Cyan, trackColor = Cyan.copy(.15f)) }
                }
                item { CBtn("Refresh") { tick++ } }
            }
        }
    }
}

// ---------- Settings ----------
@Composable fun SettingsScreen(msgs: SnapshotStateList<Msg>) {
    val c = LocalContext.current
    var url by remember { mutableStateOf(Store.get(c, "url")) }; var token by remember { mutableStateOf(Store.get(c, "token")) }
    var lang by remember { mutableStateOf(Store.get(c, "lang", "Auto")) }
    var voice by remember { mutableStateOf(Store.get(c, "voice", "1") == "1") }; var save by remember { mutableStateOf(Store.get(c, "save", "1") == "1") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Title("SETTINGS")
        Field(url, { url = it; Store.put(c, "url", it) }, "Backend URL (https://…workers.dev)", Modifier.fillMaxWidth())
        Field(token, { token = it; Store.put(c, "token", it) }, "App Token", Modifier.fillMaxWidth())
        Text("Language")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Auto", "English", "Tamil", "Tanglish").forEach { l ->
                FilterChip(lang == l, { lang = l; Store.put(c, "lang", l) }, { Text(l) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Cyan.copy(.3f)))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("JARVIS speaks replies", Modifier.weight(1f)); Switch(voice, { voice = it; Store.put(c, "voice", if (it) "1" else "0") }) }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Save chat history on this phone", Modifier.weight(1f))
            Switch(save, { save = it; Store.put(c, "save", if (it) "1" else "0"); if (!it) Store.put(c, "hist", "[]") }) }
        Glow(Modifier.fillMaxWidth()) {
            Text("Privacy", color = Cyan)
            Text("Only the chat text you send goes to your own backend and then Claude. Your API key lives only on the backend. Screen-time data, notes, tasks and focus stats never leave this phone.", fontSize = 13.sp, color = Color.Gray)
        }
        CBtn("Clear chat history", Modifier.fillMaxWidth()) { msgs.clear(); Store.put(c, "hist", "[]") }
        CBtn("Erase ALL app data", Modifier.fillMaxWidth()) {
            c.getSharedPreferences("jarvis", 0).edit().clear().apply(); msgs.clear(); url = ""; token = ""; lang = "Auto"; voice = true; save = true
        }
    }
}
