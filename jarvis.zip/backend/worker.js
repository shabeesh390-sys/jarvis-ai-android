// Cloudflare Worker: keeps your Claude API key off the phone.
// Secrets to set: ANTHROPIC_API_KEY, APP_TOKEN (any password you invent)
const J = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json" } });
export default {
  async fetch(req, env) {
    if (req.method !== "POST") return new Response("JARVIS backend online");
    if (req.headers.get("X-App-Token") !== env.APP_TOKEN) return J({ text: "Unauthorized: check App Token in Settings." }, 401);
    const { system, messages } = await req.json();
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: env.MODEL || "claude-sonnet-5-5", max_tokens: 2048, system: String(system || "").slice(0, 6000), messages: (messages || []).slice(-30) }),
    });
    const d = await r.json();
    return J({ text: d.content?.[0]?.text ?? "API error: " + JSON.stringify(d).slice(0, 300) });
  },
};
